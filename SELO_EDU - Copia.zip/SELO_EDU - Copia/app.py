from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        # Aqui você poderia validar email e senha
        # Por enquanto só redireciona de volta para a home
        return redirect(url_for("home"))
    return render_template("AUTH/login.html")
